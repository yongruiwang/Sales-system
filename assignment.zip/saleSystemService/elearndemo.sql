/*
Navicat MySQL Data Transfer

Source Server         : localhost_3306
Source Server Version : 50724
Source Host           : localhost:3306
Source Database       : elearndemo

Target Server Type    : MYSQL
Target Server Version : 50724
File Encoding         : 65001

Date: 2019-12-05 12:28:39
*/

use  salesystem;
SET FOREIGN_KEY_CHECKS=0;
-- ----------------------------
-- Table structure for `course`
-- ----------------------------
DROP TABLE IF EXISTS `course`;
CREATE TABLE `course` (
                          `id` varchar(20) NOT NULL,
                          `name` varchar(50) NOT NULL,
                          `code` varchar(50) NOT NULL,
                          `category_id` varchar(20) DEFAULT NULL,
                          `description` varchar(50) DEFAULT NULL,
                          `price` varchar(50) DEFAULT NULL,
                          `status` varchar(50) DEFAULT NULL,
                          `open_date` date DEFAULT NULL,
                          `last_update_on` datetime DEFAULT NULL,
                          `level` varchar(20) DEFAULT NULL,
                          `shared` varchar(20) DEFAULT NULL,
                          `shared_url` varchar(50) DEFAULT NULL,
                          `avatar` varchar(100) DEFAULT NULL,
                          `big_avatar` varchar(100) DEFAULT NULL,
                          `certification` varchar(50) DEFAULT NULL,
                          `certification_duration` varchar(50) DEFAULT NULL,
                          PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of course
-- ----------------------------
INSERT INTO course VALUES ('001', '梨花春', '2019SSE_001', 'ICT_SW_001', 'A course for basic android appication development', '1', 'Open', '2019-09-01', '2019-11-25 09:01:20', '基础', '0', null, '001\\av001.jpg', null, 'BJTU', 'Forever');
INSERT INTO course VALUES ('002', '泸州老窖', '2019SSE_002', 'ICT_SW_002', 'HTML, CSS, JS and basic Web Server technologies.', '1', 'Open', '2019-09-06', '2019-11-26 10:11:42', '中级', '0', null, '002\\av001.jpg', null, 'BJTU SSE', 'Forever');
INSERT INTO course VALUES ('003', '老白干', '2019SSE_002', 'ICT_SW_002', 'HTML, CSS, JS and basic Web Server technologies.', '1', 'Open', '2019-09-06', '2019-11-26 10:11:42', '基础', '0', null, '003\\av001.jpg', null, 'BJTU', 'Forever');
INSERT INTO course VALUES ('004', '五粮液', '2019SSE_002', 'ICT_SW_002', 'HTML, CSS, JS and basic Web Server technologies.', '1', 'Open', '2019-09-06', '2019-11-26 10:11:42', '高级', '0', null, '004\\av001.jpg', null, 'NJTU', 'Forever');
INSERT INTO course VALUES ('005', '江小白', '2019SSE_002', 'ICT_SW_002', 'HTML, CSS, JS and basic Web Server technologies.', '1', 'Close', '2019-09-06', '2019-11-26 10:11:42', '基础', '0', null, '005\\av001.jpg', null, 'NJTU', 'Forever');
INSERT INTO course VALUES ('006', '红塔山', '2019SSE_002', 'ICT_SW_002', 'HTML, CSS, JS and basic Web Server technologies.', '1', 'Open', '2019-09-06', '2019-11-26 10:11:42', '高级', '0', null, '006\\av001.jpg', null, 'BJTU SSE', 'Forever');
INSERT INTO course VALUES ('007', '黄鹤楼', '2019SSE_002', 'ICT_SW_002', 'HTML, CSS, JS and basic Web Server technologies.', '1', 'Open', '2019-09-06', '2019-11-26 10:11:42', '中级', '0', null, '007\\av001.jpg', null, 'BJTU', 'Forever');
INSERT INTO course VALUES ('008', '芙蓉王', '2019SSE_002', 'ICT_SW_002', 'HTML, CSS, JS and basic Web Server technologies.', '1', 'Close', '2019-09-06', '2019-11-26 10:11:42', '基础', '0', null, '008\\av001.jpg', null, 'BJTU SSE', 'Forever');
INSERT INTO course VALUES ('009', '酱香土豆', '2019SSE_002', 'ICT_SW_002', 'HTML, CSS, JS and basic Web Server technologies.', '2', 'Open', '2019-09-06', '2019-11-26 10:11:42', '高级', '0', null, '009\\av001.jpg', null, 'BJTU', 'Forever');
INSERT INTO course VALUES ('010', '康师傅牛肉面', '2019SSE_002', 'ICT_SW_002', 'HTML, CSS, JS and basic Web Server technologies.', '2', 'Close', '2019-09-06', '2019-11-26 10:11:42', '基础', '0', null, '010\\av001.jpg', null, 'BJTU', 'Forever');
INSERT INTO course VALUES ('011', '老干妈', '2019SSE_002', 'ICT_SW_002', 'HTML, CSS, JS and basic Web Server technologies.', '2', 'Close', '2019-09-06', '2019-11-26 10:11:42', '中级', '0', null, '011\\av001.jpg', null, 'BJTU', 'Forever');
INSERT INTO course VALUES ('012', '冰糖雪梨', '2019SSE_002', 'ICT_SW_002', 'HTML, CSS, JS and basic Web Server technologies.', '2', 'Open', '2019-09-06', '2019-11-26 10:11:42', '中级', '0', null, '012\\av001.jpg', null, 'BJTU SSE', 'Forever');
INSERT INTO course VALUES ('013', '优酸乳', '2019SSE_002', 'ICT_SW_002', 'HTML, CSS, JS and basic Web Server technologies.', '2', 'Open', '2019-09-06', '2019-11-26 10:11:42', '中级', '0', null, '012\\av001.jpg', null, 'BJTU SSE', 'Forever');
INSERT INTO course VALUES ('014', '雪碧', '2019SSE_002', 'ICT_SW_002', 'HTML, CSS, JS and basic Web Server technologies.', '2', 'Open', '2019-09-06', '2019-11-26 10:11:42', '中级', '0', null, '012\\av001.jpg', null, 'BJTU SSE', 'Forever');
INSERT INTO course VALUES ('015', '铅笔', '2019SSE_002', 'ICT_SW_002', 'HTML, CSS, JS and basic Web Server technologies.', '3', 'Open', '2019-09-06', '2019-11-26 10:11:42', '中级', '0', null, '012\\av001.jpg', null, 'BJTU SSE', 'Forever');
INSERT INTO course VALUES ('016', '橡皮', '2019SSE_002', 'ICT_SW_002', 'HTML, CSS, JS and basic Web Server technologies.', '3', 'Open', '2019-09-06', '2019-11-26 10:11:42', '中级', '0', null, '012\\av001.jpg', null, 'BJTU SSE', 'Forever');
INSERT INTO course VALUES ('017', '语文本', '2019SSE_002', 'ICT_SW_002', 'HTML, CSS, JS and basic Web Server technologies.', '3', 'Open', '2019-09-06', '2019-11-26 10:11:42', '中级', '0', null, '012\\av001.jpg', null, 'BJTU SSE', 'Forever');
INSERT INTO course VALUES ('018', '胶带', '2019SSE_002', 'ICT_SW_002', 'HTML, CSS, JS and basic Web Server technologies.', '4', 'Open', '2019-09-06', '2019-11-26 10:11:42', '中级', '0', null, '012\\av001.jpg', null, 'BJTU SSE', 'Forever');
INSERT INTO course VALUES ('019', '水杯', '2019SSE_002', 'ICT_SW_002', 'HTML, CSS, JS and basic Web Server technologies.', '4', 'Open', '2019-09-06', '2019-11-26 10:11:42', '中级', '0', null, '012\\av001.jpg', null, 'BJTU SSE', 'Forever');
INSERT INTO course VALUES ('020', '图钉', '2019SSE_002', 'ICT_SW_002', 'HTML, CSS, JS and basic Web Server technologies.', '4', 'Open', '2019-09-06', '2019-11-26 10:11:42', '中级', '0', null, '012\\av001.jpg', null, 'BJTU SSE', 'Forever');
INSERT INTO course VALUES ('021', '飘柔洗发水', '2019SSE_002', 'ICT_SW_002', 'HTML, CSS, JS and basic Web Server technologies.', '4', 'Open', '2019-09-06', '2019-11-26 10:11:42', '中级', '0', null, '012\\av001.jpg', null, 'BJTU SSE', 'Forever');

-- ----------------------------
-- Table structure for `material`
-- ----------------------------
DROP TABLE IF EXISTS `material`;
CREATE TABLE `material` (
                            `id` varchar(20) NOT NULL,
                            `course_id` varchar(20) NOT NULL,
                            `mediatype` varchar(20) NOT NULL,
                            `material_type` varchar(50) DEFAULT NULL,
                            `material_url` varchar(100) DEFAULT NULL,
                            `create_date` datetime DEFAULT NULL,
                            `description` varchar(50) DEFAULT NULL,
                            `status` varchar(50) DEFAULT NULL,
                            PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of material
-- ----------------------------
INSERT INTO material VALUES ('1', '001', 'video', 'lecture video', '001\\v1.mp4', '2019-12-04 22:06:49', null, '1');
INSERT INTO material VALUES ('2', '001', 'image', 'image', '001\\boat.jpg', '2019-12-04 22:07:49', null, '1');
INSERT INTO material VALUES ('3', '001', 'audio', 'lecture audio', '001\\joy.mp3', '2019-12-04 22:08:26', null, '1');
INSERT INTO material VALUES ('4', '001', 'pdf', 'slide pdf', '001\\python.pdf', '2019-12-04 22:08:57', null, '1');
INSERT INTO material VALUES ('5', '001', 'video', 'lecture video', '001\\v2.mp4', '2019-12-04 22:06:49', null, '1');
INSERT INTO material VALUES ('6', '001', 'video', 'lecture video', '001\\v3.mp4', '2019-12-04 22:06:49', null, '1');
INSERT INTO material VALUES ('7', '001', 'video', 'lecture video', '001\\v4.mp4', '2019-12-04 22:06:49', null, '1');
INSERT INTO material VALUES ('8', '001', 'video', 'lecture video', '001\\v5.mp4', '2019-12-04 22:06:49', null, '1');
INSERT INTO material VALUES ('9', '002', 'video', 'lecture video', '002\\v1.mp4', '2019-12-04 22:06:49', null, '1');
INSERT INTO material VALUES ('10', '002', 'video', 'lecture video', '002\\v2.mp4', '2019-12-04 22:06:49', null, '1');
INSERT INTO material VALUES ('11', '002', 'video', 'lecture video', '002\\v3.mp4', '2019-12-04 22:06:49', null, '1');
INSERT INTO material VALUES ('12', '002', 'video', 'lecture video', '002\\v4.mp4', '2019-12-04 22:06:49', null, '1');
INSERT INTO material VALUES ('13', '002', 'video', 'lecture video', '002\\v5.mp4', '2019-12-04 22:06:49', null, '1');
INSERT INTO material VALUES ('14', '003', 'video', 'lecture video', '003\\v5.mp4', '2019-12-04 22:06:49', null, '1');
INSERT INTO material VALUES ('15', '004', 'video', 'lecture video', '004\\v5.mp4', '2019-12-04 22:06:49', null, '1');
INSERT INTO material VALUES ('16', '005', 'video', 'lecture video', '005\\v5.mp4', '2019-12-04 22:06:49', null, '1');
INSERT INTO material VALUES ('17', '006', 'video', 'lecture video', '006\\v5.mp4', '2019-12-04 22:06:49', null, '1');
INSERT INTO material VALUES ('18', '007', 'video', 'lecture video', '007\\v5.mp4', '2019-12-04 22:06:49', null, '1');
INSERT INTO material VALUES ('19', '008', 'video', 'lecture video', '008\\v5.mp4', '2019-12-04 22:06:49', null, '1');
INSERT INTO material VALUES ('20', '009', 'video', 'lecture video', '009\\v5.mp4', '2019-12-04 22:06:49', null, '1');
INSERT INTO material VALUES ('21', '010', 'video', 'lecture video', '010\\v5.mp4', '2019-12-04 22:06:49', null, '1');
INSERT INTO material VALUES ('22', '011', 'video', 'lecture video', '011\\v5.mp4', '2019-12-04 22:06:49', null, '1');
INSERT INTO material VALUES ('23', '012', 'video', 'lecture video', '012\\v5.mp4', '2019-12-04 22:06:49', null, '1');


-- ----------------------------
-- Table structure for `teacher`
-- ----------------------------
DROP TABLE IF EXISTS `teacher`;
CREATE TABLE `teacher` (
                           `userid` varchar(20) NOT NULL,
                           `course_id` varchar(20) NOT NULL,
                           `name` varchar(50) NOT NULL,
                           `photo` varchar(100) DEFAULT NULL,
                           `telephone` varchar(20) DEFAULT NULL,
                           `email` varchar(50) DEFAULT NULL,
                           `description` varchar(50) DEFAULT NULL,
                           PRIMARY KEY (`userid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of teacher
-- ----------------------------
INSERT INTO teacher VALUES ('1', '001', 'Wang Hong', '001\\wang.png', '01051690273', 'wang@bjtu.edu', 'android teacher');
INSERT INTO teacher VALUES ('2', '002', '张亮', '002\\zhang.jpg', '01051680732', 'zhang@bjtu.edu', 'web development teacher');


-- ----------------------------
-- Table structure for `user`
-- ----------------------------
DROP TABLE IF EXISTS `user`;
CREATE TABLE `user` (
                        `userid` int(6) zerofill NOT NULL AUTO_INCREMENT,
                        `name` varchar(50) NOT NULL,
                        `password` varchar(100) DEFAULT NULL,
                        `icon` varchar(20) DEFAULT '0',
                        PRIMARY KEY (`userid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of user
-- ----------------------------
INSERT INTO user (name,password)VALUES ('刘洋','12345');
INSERT INTO user (name,password)VALUES ('王永瑞','12345');



-- ----------------------------
-- Table structure for `subscribe`
-- ----------------------------
DROP TABLE IF EXISTS `subscribe`;
CREATE TABLE `subscribe` (
                             `userid` int(6) NOT NULL,
                             `course` varchar(20) NOT NULL,
                             `last` int NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of subscribe
-- ----------------------------
INSERT INTO subscribe (userid,course)VALUES (1,'001');
INSERT INTO subscribe (userid,course)VALUES (1,'002');
INSERT INTO subscribe (userid,course)VALUES (1,'004');
INSERT INTO subscribe (userid,course)VALUES (1,'005');
INSERT INTO subscribe (userid,course)VALUES (2,'002');