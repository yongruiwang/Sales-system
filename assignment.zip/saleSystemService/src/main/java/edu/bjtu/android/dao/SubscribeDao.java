package edu.bjtu.android.dao;

import edu.bjtu.android.entity.Subscribe;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public class SubscribeDao implements SubscribeMapper {

    @Autowired
    SubscribeMapper mapper;

    @Override
    public int insert(Subscribe record) {
        return 0;
    }

    @Override
    public List<Subscribe> selectAll() {
        return null;
    }

    @Override
    public List<Subscribe> selectByUid(int uid) {
        return mapper.selectByUid(uid);
    }

    @Override
    public Integer deleteSubscribe(String userid, String course) {
        return mapper.deleteSubscribe(userid,course);
    }

    @Override
    public Integer subscribe(String userid, String course) {
        Subscribe sub=new Subscribe();
        sub.setUserid(Integer.parseInt(userid));
        sub.setCourse(course);
        sub.setLast(0);
        return mapper.insert(sub);
    }


}
