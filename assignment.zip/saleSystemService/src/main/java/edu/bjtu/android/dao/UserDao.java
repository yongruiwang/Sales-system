package edu.bjtu.android.dao;

import java.util.List;

import edu.bjtu.android.entity.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import edu.bjtu.android.entity.User;

@Component
public class UserDao implements UserMapper{

    @Autowired
    UserMapper mapper;

    @Override
    public int deleteByPrimaryKey(String userid) {
        return 0;
    }

    @Override
    public int insert(User record) {
        return 0;
    }

    @Override
    public User selectByPrimaryKey(String userid) {
        return mapper.selectByPrimaryKey(userid);
    }

    @Override
    public List<User> selectAll() {
        return null;
    }

    @Override
    public int updateByPrimaryKey(User record) {
        return 0;
    }

    @Override
    public String newUser(String name, String password) {
        if(mapper.selectByUserName(name)==null){
            User user=new User();
            user.setName(name);
            user.setPassword(password);
            mapper.insert(user);
            return user.getUserid();
        }else{
            return "-1";
        }
    }

    @Override
    public User selectByUserName(String name) {
        return mapper.selectByUserName(name);
    }
}
