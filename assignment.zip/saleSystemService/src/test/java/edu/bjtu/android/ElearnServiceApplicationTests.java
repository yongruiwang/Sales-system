package edu.bjtu.android;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ElearnServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
