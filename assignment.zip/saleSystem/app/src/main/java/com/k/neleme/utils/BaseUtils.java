package com.k.neleme.utils;


import android.content.Context;

import com.k.neleme.bean.CommentBean;
import com.k.neleme.bean.FoodBean;
import com.k.neleme.bean.TypeBean;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.math.BigDecimal;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.ProtocolException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class BaseUtils {

	public static List<TypeBean> getTypes() {
		final ArrayList<TypeBean> tList = new ArrayList<>();
		new Thread(new Runnable() {
			@Override
			public void run() {
				HttpURLConnection connection = null;
				BufferedReader reader = null;
				try {
					URL url = new URL("http://192.168.43.27:8080/elearn/subscribe/1");
					connection = (HttpURLConnection) url.openConnection();
					//设置请求方法
					connection.setRequestMethod("GET");
					//设置连接超时时间（毫秒）
					connection.setConnectTimeout(5000);
					//设置读取超时时间（毫秒）
					connection.setReadTimeout(5000);

					//返回输入流
					InputStream in = connection.getInputStream();

					//读取输入流
					reader = new BufferedReader(new InputStreamReader(in));
					final StringBuilder result = new StringBuilder();
					String line;
					while ((line = reader.readLine()) != null) {
						result.append(line);
					}
					final JSONArray jsonArray = new JSONArray(result.toString());

					for (int i =0 ; i <jsonArray.length() ;i++) {
						JSONObject jsonObject = jsonArray.getJSONObject(i);
						String typeName = jsonObject.optString("course");
						TypeBean typeBean = new TypeBean();
						typeBean.setName(typeName);
						tList.add(typeBean);
					}

				} catch (MalformedURLException e) {
					e.printStackTrace();
				} catch (ProtocolException e) {
					e.printStackTrace();
				} catch (IOException e) {
					e.printStackTrace();
				} catch (JSONException e) {
					e.printStackTrace();
				} finally {
					if (reader != null) {
						try {
							reader.close();
						} catch (IOException e) {
							e.printStackTrace();
						}
					}
					if (connection != null) {//关闭连接
						connection.disconnect();
					}
				}
			}
		}).start();
		return tList;
	}

	public static List<FoodBean> getDatas(final Context context) {
		final ArrayList<FoodBean> fList = new ArrayList<>();

//		for (int i = 0; i < 91; i++) {
//			FoodBean foodBean = new FoodBean();
//			foodBean.setId(i);
//			foodBean.setName("食品--" + i + 1);
//			foodBean.setPrice(BigDecimal.valueOf((new Random().nextDouble() * 100)).setScale(1, BigDecimal.ROUND_HALF_DOWN));
//			foodBean.setSale("月售" + new Random().nextInt(100));
//			foodBean.setType("类别" + i / 10);
//			int resID = context.getResources().getIdentifier("food" + new Random().nextInt(8), "drawable", "com.k.neleme");
//			foodBean.setIcon(resID);
//			fList.add(foodBean);
//		}

		//开启线程，发送请求
		new Thread(new Runnable() {
			@Override
			public void run() {
				HttpURLConnection connection = null;
				BufferedReader reader = null;
				try {
					URL url = new URL("http://192.168.43.27:8080/elearn/courses");
					connection = (HttpURLConnection) url.openConnection();
					//设置请求方法
					connection.setRequestMethod("GET");
					//设置连接超时时间（毫秒）
					connection.setConnectTimeout(5000);
					//设置读取超时时间（毫秒）
					connection.setReadTimeout(5000);

					//返回输入流
					InputStream in = connection.getInputStream();

					//读取输入流
					reader = new BufferedReader(new InputStreamReader(in));
					final StringBuilder result = new StringBuilder();
					String line;
					while ((line = reader.readLine()) != null) {
						result.append(line);
					}
					final JSONArray jsonArray = new JSONArray(result.toString());

					for (int i =0 ; i <jsonArray.length() ;i++) {
						JSONObject jsonObject = jsonArray.getJSONObject(i);
						String id = jsonObject.optString("id");
						String name = jsonObject.optString("name");
						String type = jsonObject.optString("code");
						String price = jsonObject.optString("price");
						FoodBean foodBean = new FoodBean();
						foodBean.setId(id);
						foodBean.setName(name);
						foodBean.setPrice(BigDecimal.valueOf(Double.parseDouble(price)).setScale(1, BigDecimal.ROUND_HALF_DOWN));
						foodBean.setSale("月售" + new Random().nextInt(100));
						foodBean.setType(type);
						fList.add(foodBean);
					}
				} catch (MalformedURLException e) {
					e.printStackTrace();
				} catch (ProtocolException e) {
					e.printStackTrace();
				} catch (IOException e) {
					e.printStackTrace();
				} catch (JSONException e) {
					e.printStackTrace();
				} finally {
					if (reader != null) {
						try {
							reader.close();
						} catch (IOException e) {
							e.printStackTrace();
						}
					}
					if (connection != null) {//关闭连接
						connection.disconnect();
					}
				}
			}
		}).start();
		return fList;
	}

	public static List<FoodBean> getDetails(List<FoodBean> fList) {
		ArrayList<FoodBean> flist = new ArrayList<>();
		for (int i = 1; i < 5; i++) {
			if (fList.size() > i * 10) {
				flist.add(fList.get(i * 10 - 1));
				flist.add(fList.get(i * 10));
			} else {
				break;
			}
		}
		return flist;
	}

	public static List<CommentBean> getComment() {
		ArrayList<CommentBean> cList = new ArrayList<>();
		for (int i = 0; i < 10; i++) {
			cList.add(new CommentBean());
		}
		return cList;
	}
}
