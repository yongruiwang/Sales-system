package com.k.neleme.adapters;


import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.BaseViewHolder;
import com.k.neleme.R;
import com.k.neleme.Views.AddWidget;
import com.k.neleme.bean.FoodBean;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.ProtocolException;
import java.net.URL;
import java.util.List;

public class FoodAdapter extends BaseQuickAdapter<FoodBean, BaseViewHolder> {
    public static final int FIRST_STICKY_VIEW = 1;
    public static final int HAS_STICKY_VIEW = 2;
    public static final int NONE_STICKY_VIEW = 3;
    private List<FoodBean> flist;
    private AddWidget.OnAddClick onAddClick;
    private Context context;
    private View root;
    private ImageView imageView;

    public FoodAdapter(@Nullable List<FoodBean> data, AddWidget.OnAddClick onAddClick,
                       Context context, View root) {
        super(R.layout.item_food, data);
        flist = data;
        this.onAddClick = onAddClick;
        this.context = context;
        this.root = root;

    }
    class ViewHolder extends  RecyclerView.ViewHolder {

        private View root;
        private TextView tvCourseName;
        //private VideoView courseVideo;
        private TextView tvCertification;
        private LinearLayout llTag;
        private TextView tvSubscribe;
        private ImageView ivShare;
        private TextView tvFreeTag;
        private TextView tvLevelTag;
        private TextView tvStatusTag;
        private ImageView ivPhoto;

        public ViewHolder(@NonNull View root) {
            super(root);

            imageView = root.findViewById(R.id.iv_food);

            //courseVideo=root.findViewById(R.id.video_details);

        }
    }

    public static Bitmap setImage() {
        final Bitmap[] bitmap = new Bitmap[1];
        new Thread(new Runnable() {
            @Override
            public void run() {
                HttpURLConnection connection = null;
                BufferedReader reader = null;
                try {
                    URL url = new URL("http://localhost:8080/elearn/courses/001/photo");
                    connection = (HttpURLConnection) url.openConnection();
                    //设置请求方法
                    connection.setRequestMethod("GET");
                    //设置连接超时时间（毫秒）
                    connection.setConnectTimeout(5000);
                    //设置读取超时时间（毫秒）
                    connection.setReadTimeout(5000);

                    //返回输入流
                    InputStream in = connection.getInputStream();

                    //读取输入流
                    bitmap[0] = BitmapFactory.decodeStream(in);

                } catch (MalformedURLException e) {
                    e.printStackTrace();
                } catch (ProtocolException e) {
                    e.printStackTrace();
                } catch (IOException e) {
                    e.printStackTrace();
                } finally {
                    if (reader != null) {
                        try {
                            reader.close();
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }
                    if (connection != null) {//关闭连接
                        connection.disconnect();
                    }
                }
            }
        }).start();
        return bitmap[0];
    }

    @Override
    protected void convert(BaseViewHolder helper, FoodBean item) {
        helper.setText(R.id.tv_name, item.getName())
                .setText(R.id.tv_price, item.getStrPrice(mContext))
                .setText(R.id.tv_sale, item.getSale())
                .addOnClickListener(R.id.food_main)
        ;
        Glide.with(context)
             .load("http://192.168.43.27:8080/elearn/courses/"+item.getId()+"/photo")
             .into((ImageView) helper.getView(R.id.iv_food));

        Log.i("---", item.getName() + "````" + helper.getLayoutPosition());
        AddWidget addWidget = helper.getView(R.id.addwidget);
//		addWidget.setData(this, helper.getAdapterPosition(), onAddClick);
        addWidget.setData(onAddClick, item);

        if (helper.getAdapterPosition() == 0) {
            helper.setVisible(R.id.stick_header, true)
                    .setText(R.id.tv_header, item.getType())
                    .setTag(R.id.food_main, FIRST_STICKY_VIEW);
        } else {
            if (!TextUtils.equals(item.getType(), flist.get(helper.getAdapterPosition() - 1).getType())) {
                helper.setVisible(R.id.stick_header, true)
                        .setText(R.id.tv_header, item.getType())
                        .setTag(R.id.food_main, HAS_STICKY_VIEW);
            } else {
                helper.setVisible(R.id.stick_header, false)
                        .setTag(R.id.food_main, NONE_STICKY_VIEW);
            }
        }
        helper.getConvertView().setContentDescription(item.getType());
    }

}
