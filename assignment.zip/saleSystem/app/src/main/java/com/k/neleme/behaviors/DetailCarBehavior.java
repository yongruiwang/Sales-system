package com.k.neleme.behaviors;


import android.content.Context;
import android.support.design.widget.CoordinatorLayout;
import android.util.AttributeSet;
import android.view.View;

public class DetailCarBehavior extends CoordinatorLayout.Behavior<View>{
	public DetailCarBehavior() {
		super();
	}

	public DetailCarBehavior(Context context, AttributeSet attrs) {
		super(context, attrs);
	}
}
