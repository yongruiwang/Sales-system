package com.k.neleme;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.ProtocolException;
import java.net.URL;

public class Activity1 extends AppCompatActivity{
    private Activity act = this;
    private Button btn_login;
    private  Button btn_register;
    private EditText et_id;
    private EditText et_pw;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        setContentView(R.layout.activity_login);
        super.onCreate(savedInstanceState);
        btn_login = findViewById(R.id.btn_login);
        btn_register = findViewById(R.id.btn_register);
        et_id = findViewById(R.id.et_account);
        et_pw = findViewById(R.id.et_password);
        btn_login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String id=et_id.getText().toString();
                String pw=et_pw.getText().toString();
                if(id.equals("")||pw.equals("")){
                    Toast.makeText(act,"请输入用户名和密码" , Toast.LENGTH_SHORT).show();

                }else{

                    send(id,pw,view);

                }


            }
        });
        btn_register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String id=et_id.getText().toString();
                String pw=et_pw.getText().toString();
                if(id.equals("")||pw.equals("")){
                    Toast.makeText(act,"请输入要注册的用户名和密码" , Toast.LENGTH_SHORT).show();
                }else{
                    resend(id,pw,view);
                }
            }
        });
    }

    private void resend(final String id, final String pw, final View view) {
        //开启线程，发送请求
        new Thread(new Runnable() {
            @Override
            public void run() {
                HttpURLConnection connection = null;
                BufferedReader reader = null;
                final StringBuilder result = new StringBuilder();
                try {
                    URL url = new URL("http://192.168.43.27:8080/elearn/register/"+id+"/"+pw);
                    connection = (HttpURLConnection) url.openConnection();
                    //设置请求方法
                    connection.setRequestMethod("GET");
                    //设置连接超时时间（毫秒）
                    connection.setConnectTimeout(5000);
                    //设置读取超时时间（毫秒）
                    connection.setReadTimeout(5000);

                    //返回输入流
                    InputStream in = connection.getInputStream();

                    //读取输入流
                    reader = new BufferedReader(new InputStreamReader(in));

                    String line;
                    while ((line = reader.readLine()) != null) {
                        result.append(line);
                    }
                    if(result.toString().equals("-1")){
                        act.runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                act.runOnUiThread(new Runnable() {
                                    @Override
                                    public void run() {

                                        //Toast.makeText(getActivity(),result , Toast.LENGTH_SHORT).show();
                                        Toast.makeText(act,"该用户名已被使用" , Toast.LENGTH_SHORT).show();
                                    }});

                            }});
                    }else{

                        act.runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                //Toast.makeText(getActivity(),result , Toast.LENGTH_SHORT).show();
                                Toast.makeText(act,"注册成功,即将登录" , Toast.LENGTH_SHORT).show();

                            }});

                        //Toast.makeText(getActivity(),result , Toast.LENGTH_SHORT).show();

                        send(id,pw,view);
                    }
                } catch (MalformedURLException e) {
                    e.printStackTrace();
                } catch (ProtocolException e) {
                    e.printStackTrace();
                } catch (IOException e) {
                    e.printStackTrace();
                } finally {


                    if (reader != null) {
                        try {
                            reader.close();
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }
                    if (connection != null) {//关闭连接
                        connection.disconnect();
                    }
                }
            }
        }).start();
    }


    private void send(final String id, final String pw, final View view) {
        //开启线程，发送请求
        new Thread(new Runnable() {
            @Override
            public void run() {
                HttpURLConnection connection = null;
                BufferedReader reader = null;
                final StringBuilder result = new StringBuilder();
                try {

                    URL url = new URL("http://192.168.43.27:8080/elearn/login/"+id+"/"+pw);
                    connection = (HttpURLConnection) url.openConnection();
                    //设置请求方法
                    connection.setRequestMethod("GET");
                    //设置连接超时时间（毫秒）
                    connection.setConnectTimeout(5000);
                    //设置读取超时时间（毫秒）
                    connection.setReadTimeout(5000);

                    //返回输入流
                    InputStream in = connection.getInputStream();

                    //读取输入流
                    reader = new BufferedReader(new InputStreamReader(in));

                    String line;

                    while ((line = reader.readLine()) != null) {
                        result.append(line);
                    }

                    //Toast.makeText(getActivity(),String.valueOf(result.toString().equals("登陆成功")) , Toast.LENGTH_SHORT).show();

                    if(result.toString().equals("登录成功")){
                        act.runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                switch (view.getId()){
                                    case R.id.btn_login:
                                        Intent intent = new Intent(act,MainActivity.class);                                         startActivity(intent);      //看上面讲解
                                        startActivity(intent);
                                        break;
                                }
                            }});
                    }else{
                        act.runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                Toast.makeText(act,"账号或密码错误" , Toast.LENGTH_SHORT).show();
                            }});

                    }
                } catch (MalformedURLException e) {
                    e.printStackTrace();
                } catch (ProtocolException e) {
                    e.printStackTrace();
                } catch (IOException e) {
                    e.printStackTrace();
                } finally {

                    if (reader != null) {
                        try {
                            reader.close();
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }
                    if (connection != null) {//关闭连接
                        connection.disconnect();
                    }
                }
            }
        }).start();
    }
    }








